/**
 * @author Sávio Muniz
 */

exports.validateFlightQuery = function (query) {
    return {success : 'okok'}
};