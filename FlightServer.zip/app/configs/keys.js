/**
 * @author Sávio Muniz
 */

module.exports = {
    golApiKey : 'aJqPU7xNHl9qN3NVZnPaJ208aPo2Bh2p2ZV844tw'
};